<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><strong>Nombre:</strong> <?php echo e($name); ?></p>
    <p><strong>Email:</strong> <?php echo e($email); ?></p>
    <p><strong>Mensaje:</strong> <?php echo e($body); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\PinochoRestaurant\back\resources\views/emails/contact.blade.php ENDPATH**/ ?>