<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($body); ?></p>
    <h2>Detalles de la reserva:</h2>
    <li>Nombre: <?php echo e($reservationDetails->firstName); ?></li>
    <li>people: <?php echo e($reservationDetails->people); ?></li>
        <li>Teléfono: <?php echo e($reservationDetails->phone); ?></li>
        <li>Día: <?php echo e($reservationDetails->date); ?></li>
        <li>Email: <?php echo e($reservationDetails->email); ?></li>
        <li>Hora: <?php echo e($reservationDetails->time); ?></li>
        <li>Alergias o intolerancias: <?php echo e($reservationDetails->allergies); ?></li>
        <div>
        <p>Le recordamos que la mesa la guardamos 15 min. Si no pudiese venir rogamos que cancele su reserva</p>
            <p>¡Te esperamos en Restaurante Pinocho!</p>
            <p>Gracias por confiar en nosotros</p>
          
        </div>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\PinochoRestaurant\back\resources\views/emails/pinocho.blade.php ENDPATH**/ ?>