
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Confirmación de Reserva</title>
</head>
<body>
    <h1>Confirmación de Reserva</h1>
    <p>Hola <?php echo e($reservationDetails->name); ?>,</p>
    <p>Tu reserva para el <?php echo e($reservationDetails->date); ?> a las <?php echo e($reservationDetails->time); ?> será confirmada lo antes posible.</p>
    <p>Detalles de la reserva:</p>
    <ul>
        <li>Nombre: <?php echo e($reservationDetails->firstName); ?></li>
        <li>Personas: <?php echo e($reservationDetails->people); ?></li>
        <li>Teléfono: <?php echo e($reservationDetails->phone); ?></li>
        <li>Día: <?php echo e($reservationDetails->date); ?></li>
        <li>Email: <?php echo e($reservationDetails->email); ?></li>
        <li>Hora: <?php echo e($reservationDetails->time); ?></li>
        <li>Alergias o intolerancias: <?php echo e($reservationDetails->allergies); ?></li>
        
    </ul>
    <p>¡Te esperamos en Restaurante Pinocho!</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\PinochoRestaurant\back\resources\views/emails/reservationConfirmation.blade.php ENDPATH**/ ?>