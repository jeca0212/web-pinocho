<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation; // Asegúrate de importar tu modelo de Reservación
use Illuminate\Support\Facades\Mail; // Importa la fachada Mail si es necesario
use App\Mail\ReservationConfirmation; // Importa tu Mailable de confirmación de reserva

class ReservationController extends Controller
{
    public function store(Request $request)
{
    $user = auth()->user();
    if (!$user) {
        return response()->json(['message' => 'Unauthenticated.'], 401);
    }

    $totalReserved = Reservation::sum('people');
    $newReservation = $request->people;

    if (($totalReserved + $newReservation) > 75) {
        return response()->json(['message' => 'Not enough space for this reservation.'], 422);
    }

    $validated = $request->validate([
        'firstName' => 'required|string|max:255',
        'people' => 'required|integer|min:1',
        'date' => 'required|date',
        'phone' => 'required|string|max:255',
        'email' => 'required|email|max:255',
        'time' => 'required',
        'allergies' => 'nullable|string',
    ]);

    $validated['user_id'] = $user->id;

    $reservation = Reservation::create($validated);

    // Asignar valores a score y status
    $reservation->score = 5;
    $reservation->status = 'pendiente';
    $reservation->save();

     Mail::to($request->email)->send(new ReservationConfirmation($reservation));

     $ownerEmail = env('OWNER_EMAIL');
        Mail::to($ownerEmail)->send(new ReservationConfirmation($reservation));

    return response()->json(['message' => 'Reservation successfully created.']);
}
    public function index(Request $request)
    {
        $query = Reservation::query();

    if ($request->has('status')) {
        $query->where('status', $request->status);
    }

    if ($request->has('filter')) {
        $query->where('phone', $request->filter)
            ->orWhere('email', $request->filter);
    }

    $reservations = $query->get();
    return response()->json($reservations);
}

public function getAceptadas()
{
    return Reservation::where('status', 'aceptado')->get();
}

public function getRechazadas()
{
    return Reservation::where('status', 'cancelado')->get();
}

public function accept(Request $request, $id)
{
    $reservation = Reservation::findOrFail($id);

    $reservation->status = 'aceptado';
    $reservation->visible = true;
    $reservation->score = $request->score ?? 5; 

    $saved = $reservation->save();

    if (!$saved) {
        Log::info("No se pudo guardar la reserva con id: $id");
        return response()->json(['message' => 'No se pudo actualizar la reserva'], 500);
    }

    $ownerEmail = env('OWNER_EMAIL');
    $clientEmail = $reservation->email;
    $reservationDetails = Reservation::findOrFail($id);

    $data = [
        'title' => 'Reserva Aceptada',
    'body' => 'Tu reserva ha sido aceptada.',
    'reservationDetails' => $reservationDetails,
    
    ];


    Mail::send('emails.pinocho', $data, function($message) use ($ownerEmail, $clientEmail) {
        $message->to($ownerEmail)
                ->subject('Reserva Aceptada');
        $message->to($clientEmail)
                ->subject('Reserva Aceptada');
    });
   

    return response()->json($reservation, 200);
}

public function cancel(Request $request, $id)
{
    $reservation = Reservation::findOrFail($id);

    $reservation->status = 'cancelado';
    $reservation->visible = false;
    $saved = $reservation->save();

    if (!$saved) {
        Log::info("No se pudo guardar la reserva con id: $id");
        return response()->json(['message' => 'No se pudo actualizar la reserva'], 500);
    }

    $ownerEmail = env('OWNER_EMAIL');
    $clientEmail = $reservation->email;
    $reservationDetails = Reservation::findOrFail($id);

    $data = [
        'title' => 'Reserva Cancelada',
        'body' => 'Tu reserva ha sido cancelada.',
        'reservationDetails' => $reservationDetails
    ];

    Mail::send('emails.pinochoCancel', $data, function($message) use ($ownerEmail, $clientEmail) {
        $message->to($ownerEmail)
                ->subject('Reserva Cancelada');
        $message->to($clientEmail)
                ->subject('Reserva Cancelada');
    });

    return response()->json($reservation, 200);
}

    public function update(Request $request, $id)
    {
        // Buscar la reserva por ID
        $reservation = Reservation::findOrFail($id);

        $validated = $request->validate([
            'score' => 'required|integer|min:1|max:5',

        ]);

        $reservation->update($validated);



        return response()->json(['message' => 'Reserva actualizada con éxito', 'reservation' => $reservation]);
    }

    public function updateScore(Request $request, $id)
{
    $reservation = Reservation::findOrFail($id);
    

    $newScore = $request->input('score');
    $reservation->score = $newScore;

    $saved = $reservation->save();

    if (!$saved) {
        Log::info("No se pudo actualizar el score de la reserva con id: $id");
        return response()->json(['message' => 'No se pudo actualizar el score de la reserva'], 500);
    }

    return response()->json($reservation, 200);
}

    public function getReservations()
    {
        $reservations = Reservation::where('visible', true)->get();
        return response()->json($reservations, 200);
    }



    

public function destroy($id)
{
    // Buscar la reserva por ID
    $reservation = Reservation::findOrFail($id);

    // Eliminar la reserva
    $reservation->delete();

    return response()->json(['message' => 'Reservation successfully deleted.']);
}
}